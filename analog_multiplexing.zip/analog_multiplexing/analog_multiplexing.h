#ifndef ANALOG_MULTIPLEXING_H
#define ANALOG_MULTIPLEXING_H

#include <Arduino.h>

int analog(int n);

#endif
