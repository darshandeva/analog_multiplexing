#include "analog_multiplexing.h"

int analog(int n)
{ int R;
  if(n==0)
  {
    digitalWrite(3,LOW);
       digitalWrite(4,LOW);
        digitalWrite(5,LOW);
       R  =  analogRead(A0);
  }
  else if(n==1)
  {
    digitalWrite(3,LOW);
       digitalWrite(4,LOW);
        digitalWrite(5,HIGH);
      R  =  analogRead(A0);
  }
  else if(n==2)
  {
    digitalWrite(3,LOW);
       digitalWrite(4,HIGH);
        digitalWrite(5,LOW);
      R  =  analogRead(A0);
  }

  else if(n==3)
  {
    digitalWrite(3,LOW);
       digitalWrite(4,HIGH);
        digitalWrite(5,HIGH);
      R  =  analogRead(A0);
  }
  else if(n==4)
  {
    digitalWrite(3,HIGH);
       digitalWrite(4,LOW);
        digitalWrite(5,LOW);
      R  =  analogRead(A0);
  }
  else if(n==5)
  {
    digitalWrite(3,HIGH);
       digitalWrite(4,LOW);
        digitalWrite(5,HIGH);
      R  =  analogRead(A0);
  }
  else if(n==6)
  {
    digitalWrite(3,HIGH);
       digitalWrite(4,HIGH);
        digitalWrite(5,LOW);
      R  =  analogRead(A0);
  }
  else if(n==7)
  {
    digitalWrite(3,HIGH);
       digitalWrite(4,HIGH);
        digitalWrite(5,HIGH);
      R  =  analogRead(A0);
  }
  else
  {
    R=0;
  }
  return R;
}
